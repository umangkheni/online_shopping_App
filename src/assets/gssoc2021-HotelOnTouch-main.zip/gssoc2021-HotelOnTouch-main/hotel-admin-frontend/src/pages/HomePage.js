import React from 'react';
import { Wrapper } from '../components';

function HomePage(){
  return <Wrapper text='HomePage' />;
};

export default HomePage ;
