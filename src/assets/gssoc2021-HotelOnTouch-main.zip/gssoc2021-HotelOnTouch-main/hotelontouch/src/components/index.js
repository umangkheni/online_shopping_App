export { default as NavbarComponent } from './NavbarComponent';
export { default as AdminCard } from './AdminCard';
export {default as OpenSourceProgramme } from './OpensourceProgramme';
export {default as OurSolution} from './OurSolution';
export { default as AllContributors } from "./AllContributors";
export {default as Contact} from "./Contact";
