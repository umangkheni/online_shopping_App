let projectRepository = "https://github.com/ayan-biswas0412/gssoc2021-HotelOnTouch";

export { projectRepository}