### File Structure 
📦src<br>
 ┣ 📂assets<br>
 ┃ ┗ 📜gssoc.png<br>
 ┣ 📂[components-Create Your own here](https://github.com/ayan-biswas0412/gssoc2021-HotelOnTouch/tree/main/hotelontouch/src/components)<br>
 ┃ ┣ 📜Footer.js<br>
 ┃ ┣ 📜[index.js-Export your component Here](https://github.com/ayan-biswas0412/gssoc2021-HotelOnTouch/blob/main/hotelontouch/src/components/index.js)<br>
 ┃ ┣ 📜NavbarComponent.js<br>
 ┃ ┗ 📜OpensourceProgramme.js<br>
 ┣ 📂data<br>
 ┃ ┗ 📜projectData.js<br>
 ┣ 📂pages<br>
 ┃ ┣ 📜HomePage.js<br>
 ┃ ┗ 📜[index.js-Export your component Here too](https://github.com/ayan-biswas0412/gssoc2021-HotelOnTouch/blob/main/hotelontouch/src/pages/index.js)<br>
 ┣ 📜App.css<br>
 ┣ 📜App.js<br>
 ┣ 📜App.test.js<br>
 ┣ 📜index.css<br>
 ┣ 📜index.js<br>
 ┣ 📜logo.svg<br>
 ┣ 📜reportWebVitals.js<br>
 ┗ 📜setupTests.js<br>

 Regarding Project setup and Contribution, please refer [Wiki](https://github.com/ayan-biswas0412/gssoc2021-HotelOnTouch/wiki)
